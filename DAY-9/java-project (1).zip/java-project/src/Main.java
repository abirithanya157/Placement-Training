
import java.util.Scanner;
class Main{
    public static void main(String[] args){
    System.out.print("Enter the correct pin:");
     Scanner sc=new Scanner(System.in);
        int pin=sc.nextInt();
         if(pin==12345){
          System.out.println("Your pin is correct");
              Bank b=new Bank();
      System.out.println("1. Check Balance\n2. Withdraw\n3. Deposit");
             System.out.print("Enter your choice:");
             int choice=sc.nextInt();
         b.setter(5000);
        
             if(choice==1){
        System.out.println("balence: " +b.getbalence());}
             else if(choice==2){
                 System.out.print("Enter the withdraw amount:");
                 int withdraw =sc.nextInt();
                b.Awithdraw(withdraw);
                  System.out.println("Remaining Balance: " +b.amount());

             }
             else if(choice==3){
                 System.out.print("Enter the deposit amount:");
                 int deposit=sc.nextInt();
                b.Adeposit(deposit);
         System.out.println("Remaining deposit: "+b.amount1());
                 
         }
    else{
     System.out.println("Your pin is not correct");}
    }
}
}
    class Bank{
    private int balence;
    private int withdraw;
    private int deposit;
    
    void setter(int balence){
        this.balence=balence;
    }
    int getbalence(){
        return balence;
    }
    void Awithdraw(int withdraw ){
        this.withdraw=withdraw;
    }
    int amount(){
        return withdraw=balence-withdraw;
    }
    void Adeposit(int deposit){
        this.deposit=deposit;  
    }
    int amount1(){
        return deposit=balence+deposit;
    }
}

